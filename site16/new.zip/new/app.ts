class Person {
    public fullName: string
    private age: number;
    private nickName: string;


    public SetAge(age: number): void {
        if (age < 18) {
            alert("LO")

        } else {
            this.age = age;
        }
    }

    public GetAge(): number {
        return this.age;
    }

    public SetNickName(nickname: string) : boolean{
        this.nickName = nickname;
        return false;
    }

    public GetNickName(): string {
        return this.nickName;
    }

}


let person1: Person = new Person();
var person2: Person = new Person();


// let p3: Person = person1;
let p3: Person;

p3.fullName = person1.fullName;



person1.fullName = "Noam";


alert(p3.fullName);
/*


person1.SetAge(15);
person1.SetNickName("Nunu");

alert(person1.fullName);
alert(person1.GetAge());
alert(person1.GetNickName())





*/



