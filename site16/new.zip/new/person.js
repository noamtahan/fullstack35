var P = /** @class */ (function () {
    function P() {
        this.age = 15;
    }
    return P;
}());
function changeAge(item) {
    item.age = 20;
}
var p1 = new P();
console.log(p1.age);
changeAge(p1);
console.log(p1.age);
