var Person = /** @class */ (function () {
    function Person() {
    }
    Person.prototype.SetAge = function (age) {
        if (age < 18) {
            alert("LO");
        }
        else {
            this.age = age;
        }
    };
    Person.prototype.GetAge = function () {
        return this.age;
    };
    Person.prototype.SetNickName = function (nickname) {
        this.nickName = nickname;
        return false;
    };
    Person.prototype.GetNickName = function () {
        return this.nickName;
    };
    return Person;
}());
var person1 = new Person();
var person2 = new Person();
// let p3: Person = person1;
var p3;
p3.fullName = person1.fullName;
person1.fullName = "Noam";
alert(p3.fullName);
/*


person1.SetAge(15);
person1.SetNickName("Nunu");

alert(person1.fullName);
alert(person1.GetAge());
alert(person1.GetNickName())





*/
