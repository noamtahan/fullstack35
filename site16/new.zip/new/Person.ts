class P {
    age: number = 15;
}

